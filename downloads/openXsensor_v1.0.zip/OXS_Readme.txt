Installation:
Put the folder "openxsensor_vx_x" in your arduino project directory.

